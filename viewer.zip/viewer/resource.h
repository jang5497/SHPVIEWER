//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SHPViewer.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SHPVIETYPE                  129
#define IDC_PANNING                     130
#define IDC_ZOOM_CENTER                 131
#define IDC_ZOOM_IN                     132
#define IDC_ZOOM_OUT                    133
#define IDD_INFO_DLG                    134
#define IDI_PLATE                       134
#define IDD_ROUTE_DLG                   136
#define IDD_DATAINFO_DLG                137
#define IDC_SELECTOR                    161
#define IDD_FIELD_DLG                   169
#define IDC_TEXTLIST                    1000
#define IDC_STARTFLAG                   1001
#define IDC_ENDFLAG                     1002
#define IDC_ROUTE                       1003
#define IDC_LIST_START                  1005
#define IDC_LIST3                       1006
#define IDC_LIST_END                    1006
#define IDC_LINKID                      1008
#define IDC_NODEID                      1009
#define IDC_LINKEXTRACT                 1010
#define IDC_NODEINFO                    1012
#define IDC_NODEEXTRACT                 1013
#define IDC_LIST1                       1020
#define IDC_LINKINFO                    1021
#define IDM_ZOOM_IN                     32771
#define IDM_ZOOM_OUT                    32772
#define IDM_ZOOM_WINDOW                 32773
#define IDM_PANNING                     32774
#define IDM_CENTER_MOVE                 32775
#define IDM_ZOOM_ALL                    32776
#define IDM_FILE_CLOSE                  32777
#define IDM_CHANGE_COLOR                32778
#define IDM_VECTOR_SELECT               32781
#define IDM_SHAPE_INFO                  32782
#define IDM_SHOW_LABEL                  32783
#define IDM_REMOVE_LABEL                32784
#define IDM_POLYGON_LINE                32785
#define ID_MENUITEM32786                32786
#define IDM_NGI_WEST                    32787
#define ID_MENUITEM32788                32788
#define IDM_NGI_CENTER                  32789
#define IDM_NGI_EAST                    32790
#define ID_MENUITEM32791                32791
#define IDM_KATEC_SYSTEM                32792
#define ID_MENUITEM32793                32793
#define IDM_UTM_ZONE51                  32794
#define IDM_UTM_ZONE52                  32795
#define ID_32796                        32796
#define ID_32797                        32797
#define ID_ROUTE                        32798
#define ID_DATA                         32799
#define ID_MENU_COLOR_CHANGE            32867
#define IDM_SIZE_0                      32871
#define IDM_SIZE_1                      32872
#define IDM_SIZE_2                      32873
#define IDM_SIZE_3                      32874
#define IDM_SIZE_4                      32875
#define IDM_SIZE_5                      32876
#define IDM_POINT_ICON                  32877
#define IDM_PS_SOLID                    32878
#define IDM_PS_DASH                     32879
#define IDM_PS_DOT                      32880
#define IDM_PS_DASHDOT                  32881
#define IDM_PS_DASHDOTDOT               32882
#define IDM_POLYGON_SOLIDBRUSH          32892
#define ID_MENU_BRUSHCOLOR_CHANGE       32899

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32800
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
